<?php
	session_start();
	$servername = "localhost";
	$dbname = "project";
	$userName = "root";
	$passWord = "";
?>